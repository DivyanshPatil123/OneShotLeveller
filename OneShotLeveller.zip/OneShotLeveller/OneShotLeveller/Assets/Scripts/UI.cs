using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class UI : MonoBehaviour
{
    // Start is called before the first frame update
    public void levelSelector()
    {
        SceneManager.LoadScene("LevelSelector");
    }

    public void instruction()
    {
        SceneManager.LoadScene("Instruction");
    }

    public void exit()
    {
        Application.Quit();
    }

    public void mainmenu()
    {
        SceneManager.LoadScene("Main Menu");
    }

    public void level1()
    {
        SceneManager.LoadScene("Level1");
    }

   public void level2()
    {
        SceneManager.LoadScene("Level2");
    }

    public void level3()
    {
        SceneManager.LoadScene("Level3");
    }

    public void level4()
    {
        SceneManager.LoadScene("Level4");
    }
}
