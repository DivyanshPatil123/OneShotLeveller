using System.Collections;
using System.Collections.Generic;
using UnityEditor.Rendering;
using UnityEngine;

public class Spring : MonoBehaviour
{
    public Rigidbody2D rb;
    public float acc;
    // Start is called before the first frame update


    private void Start()
    {
        rb = GameObject.Find("Circle").GetComponent<Rigidbody2D>();
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.transform.name == "Circle")
        {
            Debug.Log("hit");
            rb.AddForce(new Vector2(0, acc), ForceMode2D.Impulse);
        }
        


    }
}
