using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    // Start is called before the first frame update
    public Rigidbody2D rbcircle;
    
    public float velocity;
    bool isStart;
    void Start()
    {
        isStart = false;
    }

    // Update is called once per frame
    void Update()
    {
        
        if(Input.GetKeyDown(KeyCode.Space) && !isStart)
         {
            isStart = true;
            rbcircle.velocity = new Vector2(velocity, 0f);

        }
    }
}
