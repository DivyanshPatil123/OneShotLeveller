using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bomb : MonoBehaviour
{
    // Start is called before the first frame update
    GameObject circle;
    Rigidbody2D rb;
    public float acc;
    Vector2 up;
    public float ang;
    Vector2 Pos;
    public Animator anim;
    void Start()
    {
        up = new Vector2(0, 1);
    }

    // Update is called once per frame
    void Update()
    {
        circle = GameObject.Find("Circle");
        rb = GameObject.Find("Circle").GetComponent<Rigidbody2D>();
        Pos = new Vector2(circle.transform.position.x - gameObject.transform.position.x, circle.transform.position.y - gameObject.transform.position.y);
        ang = Vector2.SignedAngle(up, Pos);
        Debug.Log(ang);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {   
        if (collision.gameObject.transform.name == "Circle")
        {   
            if (ang < 45 && ang > -45)
            {


                rb.AddForce(new Vector2(0, acc), ForceMode2D.Impulse);

            }
            if (ang > 45)
            {
                rb.AddForce(new Vector2(-acc, 0), ForceMode2D.Impulse);
            }
            if (ang <- 45)
            {
                rb.AddForce(new Vector2(acc, 0), ForceMode2D.Impulse);
            }
            Destroy(gameObject);
        }
        



    }
}
