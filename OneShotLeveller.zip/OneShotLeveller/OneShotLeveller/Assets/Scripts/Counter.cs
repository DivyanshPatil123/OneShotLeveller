using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.Assertions.Must;

public class Counter : MonoBehaviour
{
    // Start is called before the first frame update
    public int bomb;
    public int spring;
    public int block;
    public TMP_Text bomb_no;
    public TMP_Text spring_no;
    public TMP_Text block_no;
    void Start()
    {
       
      
    }

    // Update is called once per frame
    void Update()
    {
        bomb_no.text = bomb.ToString();
        spring_no.text = spring.ToString();
        block_no.text = block.ToString();
    }
}
