using UnityEngine;

public class EndPortal : MonoBehaviour
{
    private GameManager gameManager; 

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            if (gameManager.CoinsCollected >= gameManager.CoinsNeeded)
            {
                gameManager.WinGame();
           
            }
            else
            {
                gameManager.LoseGame();
            }
        }
    }

    public void SetGameManager(GameManager manager)
    {
        gameManager = manager;
    }
}
