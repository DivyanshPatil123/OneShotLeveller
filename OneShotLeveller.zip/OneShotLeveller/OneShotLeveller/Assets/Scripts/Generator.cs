using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Generator : MonoBehaviour
{
    public GameObject bo;
    public GameObject sp1;
    public GameObject block;
    bool istrue;
    public Counter cs;
    public Vector3 pos;
    // Start is called before the first frame update
    void Start()
    {
        istrue = true;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void clicker()
    {   if (cs.bomb != 0)
        {
            cs.bomb--;
            if (istrue)
            {
                Instantiate(bo, pos, Quaternion.identity);
                
            }
        }
    }

    public void clickex()
    {
        if (cs.spring != 0)
        {
            cs.spring--;
            if (istrue)
            {
                Instantiate(sp1, pos, Quaternion.identity);

            }
        }
    }

    public void clickey()
    {
        if (cs.block != 0)
        {
            cs.block--;
            if (istrue)
            {
                Instantiate(block, pos, Quaternion.identity);

            }
        }
    }
}
