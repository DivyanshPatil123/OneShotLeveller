using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public int CoinsCollected = 0;
    public int CoinsNeeded = 3;
    public TextMeshProUGUI CoinsCollectedText;
    public Canvas c1;
    public Canvas c2;
    public Canvas c3;

    private void Start()
    {
        c3.gameObject.SetActive(false);
        GameObject coinObj = GameObject.FindGameObjectWithTag("Coin");
        Coin[] coins = FindObjectsOfType<Coin>();
       for (int i = 0; i < coins.Length; i++)
     {
      Coin coin = coins[i];
      coin.SetGameManager(this);
     }

        // Coin coin = coinObj.GetComponent<Coin>();
        // coin.SetGameManager(this);

        GameObject endPortalObj = GameObject.FindGameObjectWithTag("EndPortal");
        EndPortal endPortal = endPortalObj.GetComponent<EndPortal>();
        endPortal.SetGameManager(this);

        //CoinsCollectedText = GameObject.Find("CoinsCollectedText").GetComponent<TextMeshProUGUI>();
    }

    public void CollectCoin()
    {
        CoinsCollected++;
        Debug.Log("Coin Collected! Total: " + CoinsCollected);
        CoinsCollectedText.text = "Coins: " + CoinsCollected.ToString();
    }

    public void WinGame()
    {
        
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }

    public void LoseGame()
    {
        Debug.Log("You Lose!");
        c1.gameObject.SetActive(false);
        c2.gameObject.SetActive(false);
        c3.gameObject.SetActive(true);
       //SceneManager.LoadScene("Lose");
    }
}
